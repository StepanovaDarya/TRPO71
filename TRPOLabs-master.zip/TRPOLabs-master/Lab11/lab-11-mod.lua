local me = {}

function me.lua_swap(a,b)
  return b, a
end
function me.lua_sum(a,b)
  return b+a
end


return me